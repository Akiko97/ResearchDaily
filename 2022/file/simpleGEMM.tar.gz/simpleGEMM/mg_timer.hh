/**
 * @file    mg_timer.hh
 * @brief   time handling APIs
 * @author  Masato Gocho <gocho@ueda.info.waseda.ac.jp>
 *
 * Copyright(C) 2020, Ueda Lab. Waseda Univ. All Right Reserved
 */

#ifndef __MG_TIMER_HH
#define __MG_TIMER_HH

namespace timer {
  
  double get_time( void );
  
  static inline void tic( double &t ) { t = get_time( );     } 
  static inline void toc( double &t ) { t = get_time( ) - t; }
  static inline void toc_tic( double &ed, double &st ) {
    double t = get_time( );
    ed = t - ed;
    st = t;
  }
  
}/*end of namespace "timer"*/

#endif/*__MG_TIMER_HH*/
