/**
 * @file    mg_timer.cpp
 * @brief   time handling APIs
 * @author  Masato Gocho <gocho@ueda.info.waseda.ac.jp>
 *
 * Copyright(C) 2020, Ueda Lab. Waseda Univ. All Right Reserved
 */

#include "mg_timer.hh"
#include "mg_timer.h"
#include <time.h>
#include <sys/time.h>

namespace timer {
  
  double get_time( )
  {
#if 1
    struct timeval tv;
    gettimeofday( &tv, NULL );
    return tv.tv_sec + tv.tv_usec * 1e-6;
#else
    struct timespec ts;
    clock_gettime( CLOCK_MONOTONIC, &ts );
    return ts.tv_sec + ts.tv_nsec * 1e-9;
#endif
  }
  
}/*end of namespace "timer"*/


extern "C" {
  
  double timer_get_time( )
  {
    return timer::get_time();
  }

}


