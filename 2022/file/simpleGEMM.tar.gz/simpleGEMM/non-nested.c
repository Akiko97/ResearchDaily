#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include "mg_timer.h"

void matmul( const int *__restrict__ a,
             const int *__restrict__ b,
             int       *__restrict__ c, int M, int N, int K )
{
  for (int k = 0; k < K; k++)
    for (int i = 0; i < M; i++) {
      int t = a[i*K + k];
      for (int j = 0; j < N; j++) c[i*N+j] += t * b[k*N+j];
    }
}

int main( int argc, char *argv[] )
{
  int msize = argc >= 2 ? atoi( argv[1] ) : 128;
  printf( "matrix size : %d\n", msize );
  
  int *a = (int *)malloc( sizeof(int) * msize*msize );
  int *b = (int *)malloc( sizeof(int) * msize*msize );
  int *r = (int *)malloc( sizeof(int) * msize*msize );
  for (int i = 0; i < msize; i++) {
    for (int j = 0; j < msize; j++) {
      a[i*msize+j] = 1;
      b[i*msize+j] = 1;
      r[i*msize+j] = 0;
    }
  }

  int iter = 10;
  double time;
  timer_tic( &time );
  {
    for (int i = 0; i < iter; ++i) {
      matmul( a, b, r, msize, msize, msize );
    }
  }
  timer_toc( &time );
  printf( "%10.3f [s] (average time,  %d iterations)\n", time, iter );
  fflush( stdout );
  
  free(a);
  free(b);
  free(r);
  return 0;
}

