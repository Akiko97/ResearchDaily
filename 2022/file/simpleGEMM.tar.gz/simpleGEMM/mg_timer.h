/**
 * @file    mg_timer.h
 * @brief   C I/F for time handling APIs
 * @author  Masato Gocho <gocho@ueda.info.waseda.ac.jp>
 *
 * Copyright(C) 2022, Ueda Lab. Waseda Univ. All Right Reserved
 */

#ifndef __MG_TIMER_H
#define __MG_TIMER_H

#ifdef __cplusplus
extern "C" {
#endif

  double timer_get_time( void );

  static inline void timer_tic( double *t ) { *t = timer_get_time( );       } 
  static inline void timer_toc( double *t ) { *t = timer_get_time( ) - *t;  }
  static inline void timer_toc_tic( double *ed, double *st ) {
    double t = timer_get_time( );
    *ed = t - *ed;
    *st = t;
  }
  
#ifdef __cplusplus
}
#endif

#endif/*__MG_TIMER_H*/
